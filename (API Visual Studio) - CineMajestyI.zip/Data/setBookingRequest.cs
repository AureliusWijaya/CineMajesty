﻿namespace MoviesAPI.Data
{
    public class setBookingRequest
    {

        public string Movie_ID { get; set; }

        public int Customer_ID {get;set;}
    }
}
