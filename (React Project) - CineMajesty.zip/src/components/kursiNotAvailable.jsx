import './SeatPage.css';
import { useState } from 'react';
const KursiNotAvailable = (props)=>{
    
    return (
        <div className={`display-one-seat-not-available`}>X</div>
    )
}
export default KursiNotAvailable;